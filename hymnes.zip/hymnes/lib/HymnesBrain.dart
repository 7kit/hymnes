import 'dart:collection';
import 'package:flutter/foundation.dart';


class HymnesBrain extends ChangeNotifier {
  List<Hymne> _hymnesBank = [
  Hymne(number: 1, titre: 'Vous qui sur la terre 1 !', chant: '\t 1 \n Vous qui sur la terre habitez,\n Chantez à haute voix, chantez!\n Réjouissez-vous au Seigneur,\n Par un saint hymne à son honneur!\n \t 2 \n N’est-il pas le Dieu souverain \n Qui nous a formés de sa main, \n Nous, le peuple qu’il veut chérir, \n Et le troupeau qu’il veut nourrir?'),
  Hymne(number: 2, titre: 'Vous qui sur la terre 2 !', chant: '\t 1 \n Entrez dans son temple aujourd’hui \n Venez vous présenter à lui \n Célébrez son nom glorieux, \n Et l’élevez jusques aux cieux. \n \t 2 \n C’est un Dieu rempli de bonté, \n D’une éternelle vérité, \n Toujours propice à nos souhaits, \n Et sa grâce dure à jamais.'),
];

  UnmodifiableListView<Hymne> get hymnes {
    return UnmodifiableListView(_hymnesBank);
  }


  String getHymneChant(int hymneNumber) {
    return _hymnesBank[hymneNumber].chant;
  }

  String getHymneTitre(int hymneNumber) {
    return _hymnesBank[hymneNumber].titre;
  }

  void setHymneFavoris(int hymneNumber) {
    _hymnesBank[hymneNumber].isFavoris = !_hymnesBank[hymneNumber].isFavoris;
    notifyListeners();
  }

  bool getHymneFavoris(int hymneNumber) => _hymnesBank[hymneNumber].isFavoris;

  int nombres ()=> _hymnesBank.length;
}

enum Categorie {
  Psaumes,
  DieuLeCreateur,
  DieuAdorationEtLouanges,
  DieuLAmourDeDieu,
  JesusChristSaNaissance,
  JesusChristSonMinistere,
  JesusChristSaMort,
  JesusChristSaResurrectionEtSonAscension,
  JesusChristSonSacerdoce,
  JesusChristSonAmour,
  JesusChristSonRetourEtSonRegne,
  LeSaintEsprit,
  LaParoleDeDieuSaLoi,
  LEgliseCommunionFraternelle,
  LEgliseCulte,
  LEgliseSabbat,
  LEgliseEcoleDuSabbat,
  LEglisePriere,
  LEgliseClotureBenediction,
  LEgliseMissions,
  LEgliseDernierMessage,
  LEgliseBaptemes,
  LEgliseSainteCene,
  EvangelisationAppelAuSalut,
  EvangelisationReponseALAppel,
  VieChretienneRepentanceConversion,
  VieChretienneAmourEtFoi,
  VieChretienneJoieConfiance,
  VieChretienneConsecrationEtSanctification,
  VieChretienneCombatsEtVictoires,
  VieChretienneSecoursEtConsolation,
  EsperanceChretienne,
  ChantsDiversMatin,
  ChantsDiversSoir,
  ChantsDiversNouvelleAnne,
  ChantsDiversMariages,
  ChantsDiversFamille,
  ChantsDiversConsecrationsPasteurs,
  ChantsDiversDedicacesTemples,
  ChantsDiversChantsAdieu,
  ChantsDiversDeuil,
  ChantsDiversTemperance,
  JeunesseAppel,
  JeunesseConsecrationEtAspiration,
  JeunesseVictoireEnChrist,
  JeunesseActiviteMissionnaire,
  JeunesseRecreation,
  Enfants,
  DuosEtChoeurs,
  ChoeursDHommes,
}
enum Auteur {
  Theodore_de_Beze,

}


class Hymne{
  int number;
  String titre;
  String chant;
  bool isFavoris = false;
  Hymne({this.number, this.titre, this.chant, this.isFavoris = false});

  void toggleDone() {
    isFavoris = !isFavoris;
  }
}