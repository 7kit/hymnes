import 'package:flutter/material.dart';
import 'package:hymnes/HymnesBrain.dart';
import 'package:provider/provider.dart';

class UniqueLectureClass extends StatefulWidget {
  final int numero;
  UniqueLectureClass({this.numero});
  @override
  _UniqueLectureClassState createState() => _UniqueLectureClassState();
}

class _UniqueLectureClassState extends State<UniqueLectureClass> {
  //HymnesBrain brain = HymnesBrain();
  @override
  Widget build(BuildContext context) {
    return Consumer<HymnesBrain>(
        builder: (context, brain, child) {
      return (Scaffold(
          appBar: AppBar(
            title: Center(child: Text("Numeros"),),
            actions: <Widget>[
              IconButton(icon: brain.getHymneFavoris(widget.numero)?Icon(Icons.bookmark):Icon(Icons.book),
                onPressed:(){
                brain.setHymneFavoris(widget.numero);
                } ,)
            ],
          ),
          body: Container(
            child: Center(
              child : GestureDetector(child: Text(brain.getHymneChant(widget.numero)),
              onTap: (){
                print('${brain.getHymneFavoris(widget.numero)}');
              },),
            ),
          ))
    );});
  }
}
