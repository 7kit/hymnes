import 'dart:async';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'MyHomePage.dart';
import 'IntroScreen.dart';

class Splash extends StatefulWidget {
  @override
  _SplashState createState() => _SplashState();
}

class _SplashState extends State<Splash> {

  Future checkFirstSeen() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool _seen = (prefs.getBool('seen')?? false);

    if(_seen){
      Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (context) => MyHomePage(title:'Accueil')));
    }
    else {
      await prefs.setBool('seen', true);
      Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (context) => IntroScreen()));
    }
  }

  @override
  void initState(){
    super.initState();
    new Timer(new Duration(milliseconds: 200), (){
      checkFirstSeen();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(child: CircularProgressIndicator(),);
  }
}
